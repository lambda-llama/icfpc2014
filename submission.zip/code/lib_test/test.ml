open OUnit2

let all () = test_list [
    Gcc_test.test
  ]
